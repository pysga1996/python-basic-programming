# Python Input/Output and comment demo 
Basic input/output và comment trong Python
